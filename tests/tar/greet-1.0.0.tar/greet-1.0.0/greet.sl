export hello(name) = "hello " + name
